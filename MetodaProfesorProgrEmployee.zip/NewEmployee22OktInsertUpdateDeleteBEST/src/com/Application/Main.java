package com.Application;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
//import java.util.*;
//import java.util.Objects;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;

public class Main {

    static Scanner sc = new Scanner(System.in); // resurse!!!
    static DbManager manager = new DbManager();


    public static void main(String[] args) {
        System.out.println("Alegeti operatia");
        System.out.println("1 - Create");
        // create
        System.out.println("Introduceti numele angajatului");
        String name = sc.nextLine();
        System.out.println("Introduceti prenumele angajatului");
        String surname = sc.nextLine();
        System.out.println("Introduceti emailul angajatului");
        String email = sc.nextLine();
        System.out.println("Introduceti ziua de nastere a angajatului (zz/ll/aaaa)");
        String birthdate = sc.nextLine();
        LocalDate birth = LocalDate.parse(birthdate, DateTimeFormatter.ofPattern("dd/MM/y"));
        Employee emp = new Employee(name, surname, email, birth);
        manager.create(emp);

        System.out.println("----------00000---------------------------------");
        System.out.println("2 - Update5555");
        Employee toEdit = findEmployee("EDIT");
        System.out.println("Introduceti un nume nou sau apasati enter");
        String newName = sc.nextLine();
        toEdit.setName(newName);
        manager.update(toEdit);

        System.out.println("--------------------2222-----------------------");
        System.out.println("3 - Delete");
        Employee toDelete = findEmployee("DELETE");
        manager.delete(toDelete);

        System.out.println("-----------------------1111--------------------");
        System.out.println("4 - List");
        listEmployees();
    }


    public static Employee findEmployee(String action) {
        List<Employee> emps = listEmployees();
        System.out.println("-------------------------------------------33333");

        // de repetat daca nu se gaseste un astfel de obiect
        boolean objectFound = false;
        Employee found = null;
        while (!objectFound) {
            System.out.println("-- Alegeti va rog obiectul (Operatia: " + action + " -->");
            int id = sc.nextInt();
            sc.nextLine();
            for (Employee employee : emps) {
                if (employee.getId() == id) {
                    found = employee;
                }
            }
            if (found != null) {
                objectFound = true;
            } else {
                System.out.println("Angajatul cu id-ul " + id + " n-o fost gasit");
            }
        }
        return found;
    }


    public static List<Employee> listEmployees() {
        List<Employee> emps = manager.selectAll();
        for (Employee e : emps) {
            System.out.println(e);
        }
        return emps;
    }


//    public static void testScanner() {
//        try(Scanner sc = new Scanner(System.in)) {
//            System.out.println("Introduceti numele angajatului");
//            String name = sc.nextLine();
//            System.out.println("Introduceti prenumele angajatului");
//            String surname = sc.nextLine();
//            System.out.println("Introduceti emailul angajatului");
//            String email = sc.nextLine();
//            Employee emp = new Employee(name, surname, email);
////            manager.create(emp);
//        }
//    }


}