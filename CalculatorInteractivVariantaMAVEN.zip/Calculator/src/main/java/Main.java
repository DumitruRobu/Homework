import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.net.URL;

public class Main extends Application{
    public void start(Stage primaryStage) throws Exception {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(new URL("file:///D:/Calculator/src/main/resources/Fxml.fxml"));

        AnchorPane rezultatFinal = (AnchorPane) loader.load();
        Scene scena1 = new Scene(rezultatFinal);
        primaryStage.setScene(scena1);
        primaryStage.show();
    }
}
