package com.Application;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DbManager {
    public Connection getConnection(){
        try
        {
            Connection connection = DriverManager.getConnection
                    ("jdbc:mysql://localhost:3306/emp_manager", "root", "ORA123");
            System.out.println("Conexiune cu succes!");
            return connection;

        } catch(SQLException ex){
            System.out.println("Eroare de conexiune: "+ex.getMessage());
            return null;
        }
    }

    //- Insert(creez) noi angajati
    public void create(Employee emp)
    {
        //met1 (mai putin high-tech)!
//        String sql = "INSERT into employee2(name, surname, email) values('"+ emp.getName() + "', '"
//                +emp.getSurname() + "', '"+emp.getEmail() + "')";

        //met 2 (high tech)
        try
        {
            String sql = "INSERT into employee2(name, surname, email) values(?,?,?)";
            Connection connection = getConnection(); //cream o conexiune
            if (connection != null) //adica daca conexiunea e stabilita cu succes
            {
                PreparedStatement statement = connection.prepareStatement(sql); //pregatim statementul.
                // partea dreapta a expresiei returneaza un obiect de tip PreparedStatement
                //noi inscriem aceasta informatie din partea dr a expresiei in variabila statement
                statement.setString(1, emp.getName()); //nu scriem 0 pt ca aici numaratoarea incepe de la 1;
                //adica numararea pozitiei in acest caz nu e ca la indecsi.
                //pe poz 1 adica in locul la primul '?', inscriem emp.getName()
                statement.setString(2, emp.getSurname());
                statement.setString(3, emp.getEmail());
                int rows = statement.executeUpdate(); //returneaza nr de rinduri afectate de cererea noastra;

            }
        } catch(SQLException ex){
            System.out.println("Nu am putut face insertul!");
        }


    }
    //- Update(modific/editez)
    public void update(Employee emp, int id)
    {
        try
        {
            String sql = "UPDATE employee2 set name=?, surname=?, email=? where id = "+id;
            Connection connection = getConnection();
            if (connection != null)
            {
                PreparedStatement statement = connection.prepareStatement(sql);
                statement.setString(1, emp.getName());
                statement.setString(2, emp.getSurname());
                statement.setString(3, emp.getEmail());
                //statement.setInt(4, emp.getId());
                int rows = statement.executeUpdate();

            }
        } catch(SQLException ex){
            System.out.println("Nu am putut face update-ul");
        }
    }

    //- Delete(sterg)
    public void delete(Employee emp, int id)
    {
        try
        {
            String sql = "delete from employee2 where id = "+id;
            Connection connection = getConnection();
            if (connection != null)
            {
                PreparedStatement statement = connection.prepareStatement(sql);
                int rows = statement.executeUpdate();
            }
        } catch(SQLException ex){
            System.out.println("Nu am putut face delete-ul");
        }
    }

    // - Select(afisez)
    public List<Employee> selectAll()
    {
        List<Employee> employees = new ArrayList<>();
        try{
            //1.SQL - select
            String sql = "SELECT id, name, surname, email from employee2"; //se poate si select * from employee
            //2.getConnection
            Connection connection = getConnection();
            //3.statement
            Statement statement = connection.createStatement();
            //dupa cum observi prepare statement nu e necesar!
            ResultSet resultSet = statement.executeQuery(sql);
            //ResultSet result = e un obiect ce salveaza in el informatia in forma de tablitsa bidimensionala
            //adica un fel de matrice

            //4. afisam datele noastre cu ajutorul functiei  resultSet.next();
            //muta cursorul pe urm rind din tabelul sau, cind ajunge pe ultimu rind, returneaza false
            while (resultSet.next())
            {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("name");
                String surname = resultSet.getString("surname");
                String email = resultSet.getString("email");
                employees.add(new Employee(id, name, surname, email));
            }

        } catch(SQLException ex) {
            System.out.println("Nu am putut face selectul!");
        }
        System.out.println("ID   NUME & PRENUME       EMAIL");
        for (int i=0; i<employees.size(); i++)
        {
            System.out.print(employees.get(i).getId()+"    ");
            System.out.print(employees.get(i).getName()+" ");
            System.out.print(employees.get(i).getSurname()+"         ");
            System.out.print(employees.get(i).getEmail());
            System.out.println("");
        }

        return employees;
    }
}




//    public void update(int id, String name, String surname, String email)
//    {
//            String sql = "UPDATE employee2 set;
//            if(name != null){
//               sql+=" name=?, ";
//            if(surname != null){
//                sql +="surname =?,";
//            }
//
//
//            Connection connection = getConnection();
//            if (connection != null)
//            {
//                PreparedStatement statement = connection.prepareStatement(sql);
//                statement.setString(1, emp.getName());
//                statement.setString(2, emp.getSurname());
//                statement.setString(3, emp.getEmail());
//                //statement.setInt(4, emp.getId());
//                int rows = statement.executeUpdate();
//
//            }
//        } catch(SQLException ex){
//            System.out.println("Nu am putut face update-ul");
//        }
//    }











