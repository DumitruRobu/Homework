package com.tryCatch;

public class Main {

    public static void main(String[] args) {
        System.out.println("Hello World!");

        Id cifra = new Id();
        cifra.setId();

        while(true)
        {
            try{
                cifra.checkId();
                break;
            }
            catch(IdNotFoundException ex){
                cifra.setId();
            };
        }
    }
}
