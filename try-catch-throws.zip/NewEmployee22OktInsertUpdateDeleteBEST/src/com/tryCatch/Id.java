package com.tryCatch;
import java.util.Scanner;

public class Id {
     private int id;

    public void setId(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Introdu ID: ");
        int id = sc.nextInt();
        this.id = id;
    }

    public void checkId() throws IdNotFoundException
    {
        if (this.id>200)
        {
            System.out.println("Cifra e prea mare!");
            throw new IdNotFoundException();
        }
        else
        {
            System.out.println("Id accepted!");
        }
    }
}
