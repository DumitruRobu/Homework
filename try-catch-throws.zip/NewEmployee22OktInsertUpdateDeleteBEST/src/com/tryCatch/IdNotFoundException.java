package com.tryCatch;

public class IdNotFoundException extends Exception{

}
