package com.Application;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.time.LocalDate;

public class Employee {
    private int id;
    private String name;
    private String surname;
    private String email;
    private LocalDate birthdate; // 10/10/1985; 1985-Octombrie-10; 10-Oct-85
//    private String idnp;
//    private String phoneNumber;

    public Employee(String name, String surname, String email) {
        this.name = name;
        this.surname = surname;
        this.email = email;
    }

    public Employee(String name, String surname, String email, LocalDate birthdate) {
        this.name = name;
        this.surname = surname;
        this.email = email;
        this.birthdate = birthdate;
    }

    public Employee(int id, String name, String surname, String email) {
        this(name, surname, email);
        this.id = id;
    }


    public Employee(int id, String name, String surname, String email, LocalDate birthdate) {
        this(name, surname, email);
        this.id = id;
        this.birthdate = birthdate;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getSurname() {
        return surname;
    }

    public String getEmail() {
        return email;
    }


    public void method() {

    }

    public void setName(String name) {
        this.name = name;
        method();
    }

    public LocalDate getBirthdate() {
        return birthdate;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", surname='" + surname + '\'' +
                ", email='" + email + '\'' +
                ", birthdate=" + birthdate +
                '}';
    }
}