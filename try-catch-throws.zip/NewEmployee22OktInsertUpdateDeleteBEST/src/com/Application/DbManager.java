package com.Application;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class DbManager {

    public Connection getConnection() {
        try{
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/emp_manager", "root", "ORA123");
            return connection;
        } catch(SQLException ex) {
            System.out.println("Eroare de conexiune: " + ex.getMessage());
            return null;
        }
    }

    // create
    public void create(Employee emp) {
        try{
            String sql = "INSERT into employee2(name, surname, email, birthdate) values(?,?,?,?)";
            Connection connection = getConnection();
            if(connection != null) {
                PreparedStatement preparedStatement = connection.prepareStatement(sql);
                preparedStatement.setString(1, emp.getName());
                preparedStatement.setString(2, emp.getSurname());
                preparedStatement.setString(3, emp.getEmail());
                preparedStatement.setDate(4, Date.valueOf(emp.getBirthdate()));
                preparedStatement.executeUpdate();
                preparedStatement.close();
                connection.close();
            }
        } catch (SQLException ex) {
            System.out.println("Nu am putut face insertul!");
        }
    }
    // selectAll

    public List<Employee> selectAll() {
        List<Employee> result = new ArrayList<>();
        String sql = "SELECT id, name, surname, email, birthdate from employee2 order by id asc";

        try(Connection connection = getConnection();
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(sql)) {

            // data
            while(resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("name");
                String surname = resultSet.getString("surname");
                String email = resultSet.getString("email");
                LocalDate birthdate = resultSet.getDate("birthdate").toLocalDate();
                result.add(new Employee(id, name, surname, email, birthdate));
            }

        } catch (SQLException ex) {
            System.out.println("Nu am putut face selectul!");
        }


        return result;
    }

    // supraincarcare
//    public void update(int id, String email, String surname)
    // ArrayList<>

    // update
    public void update(Employee emp) {
        String sql = "UPDATE employee2 set name=?, surname = ?, email=?, birthdate = ? where id=?";
        Connection connection = getConnection();
        if (connection != null) {
            try {
                PreparedStatement preparedStatement = connection.prepareStatement(sql);
                preparedStatement.setString(1, emp.getName());
                preparedStatement.setString(2, emp.getSurname());
                preparedStatement.setString(3, emp.getEmail());
                preparedStatement.setDate(4, Date.valueOf(emp.getBirthdate()));
                preparedStatement.setInt(5, emp.getId());
                preparedStatement.executeUpdate();
            } catch (SQLException ex) {
                System.out.println("Nu am putut face update!");
            }
        }
    }

    // delete

    public void delete(Employee emp) {
        String sql = "DELETE FROM employee2 where id=?";
        Connection connection = getConnection();
        if (connection != null) {
            try {
                PreparedStatement preparedStatement = connection.prepareStatement(sql);
                preparedStatement.setInt(1, emp.getId());
                preparedStatement.executeUpdate();
            } catch (SQLException ex) {
                System.out.println("Nu am putut face DELETE!");
            }
        }
    }
}





