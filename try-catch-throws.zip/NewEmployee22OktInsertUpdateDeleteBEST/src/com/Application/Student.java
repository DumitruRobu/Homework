package com.Application;

public class Student {
        private int rollno;
        private String name;
        private String city;

        Student(int rollno, String name, String city)
        {
            this.rollno=rollno;
            this.name=name;
            this.city=city;
        }

        public String toString(){//overriding the toString() method
        return rollno+" "+name+" "+city;
    }
}
